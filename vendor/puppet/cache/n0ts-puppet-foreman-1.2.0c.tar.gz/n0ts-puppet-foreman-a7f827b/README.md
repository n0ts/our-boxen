# Puppet module for Foreman

[![Build Status](https://travis-ci.org/boxen/puppet-foreman.png?branch=master)](https://travis-ci.org/boxen/puppet-foreman)

Installs foreman.

## Usage

```
include foreman
```

## Required modules

* boxen (OS X only)
