# Add Foreman bins to PATH

export PATH="$BOXEN_HOME/foreman/bin:$PATH"
