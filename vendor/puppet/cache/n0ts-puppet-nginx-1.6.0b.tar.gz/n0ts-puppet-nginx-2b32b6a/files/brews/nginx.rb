class Nginx < Formula
  desc "HTTP(S) server and reverse proxy, and IMAP/POP3 proxy server"
  homepage "http://nginx.org/"
  url "http://nginx.org/download/nginx-1.9.10.tar.gz"
  sha256 "fb14d76844cab0a5a0880768be28965e74f9956790f618c454ef6098e26631d9"
  version '1.9.10-boxen2'

  skip_clean 'logs'

  depends_on 'pcre'
  depends_on "passenger" => :optional
  depends_on "openssl" => :recommended
  depends_on "libressl" => :optional

  # Before submitting more options to this formula please check they aren't
  # already in Homebrew/homebrew-nginx/nginx-full:
  # https://github.com/Homebrew/homebrew-nginx/blob/master/Formula/nginx-full.rb
  option "with-passenger", "Compile with support for Phusion Passenger module"

  def install
    pcre = Formula["pcre"]
    openssl = Formula["openssl"]
    libressl = Formula["libressl"]

    if build.with? "libressl"
      cc_opt = "-I#{pcre.include} -I#{libressl.include}"
      ld_opt = "-L#{pcre.lib} -L#{libressl.lib}"
    else
      cc_opt = "-I#{pcre.include} -I#{openssl.include}"
      ld_opt = "-L#{pcre.lib} -L#{openssl.lib}"
    end

    args = %W[
      --prefix=#{prefix}
      --with-http_ssl_module
      --with-pcre
      --with-ipv6
      --with-cc-opt=#{cc_opt}
      --with-ld-opt=#{ld_opt}
      --with-http_ssl_module
      --with-http_realip_module
      --with-http_addition_module
      --with-http_sub_module
      --with-http_dav_module
      --with-http_flv_module
      --with-http_mp4_module
      --with-http_gunzip_module
      --with-http_gzip_static_module
      --with-http_random_index_module
      --with-http_secure_link_module
      --with-http_stub_status_module
      --with-http_auth_request_module
      --with-threads
      --with-stream
      --with-stream_ssl_module
      --with-http_slice_module
      --with-mail
      --with-mail_ssl_module
      --with-http_v2_module
      --conf-path=/opt/boxen/config/nginx/nginx.conf
      --pid-path=/opt/boxen/data/nginx/nginx.pid
      --lock-path=/opt/boxen/data/nginx/nginx.lock
      --http-client-body-temp-path=/opt/boxen/data/nginxclient_body_temp
      --http-proxy-temp-path=/opt/boxen/data/nginx/proxy_temp
      --http-fastcgi-temp-path=/opt/boxen/data/nginx/fastcgi_temp
      --http-uwsgi-temp-path=/opt/boxen/data/nginx/uwsgi_temp
      --http-scgi-temp-path=/opt/boxen/data/nginx/scgi_temp
      --http-log-path=/opt/boxen/log/nginx/access.log
      --error-log-path=/opt/boxen/log/nginx/error.log
      --with-http_gzip_static_module
      --with-http_stub_status_module
    ]

    if build.with? "passenger"
      nginx_ext = `#{Formula["passenger"].opt_bin}/passenger-config --nginx-addon-dir`.chomp
      args << "--add-module=#{nginx_ext}"
    end

    system "./configure", *args
    system "make"
    system "make install"
    man8.install "objs/nginx.8"

    # remove unnecessary config files
    system "rm -rf #{etc}/nginx"
  end
end
