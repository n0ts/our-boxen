# OpenSSL Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-openssl.png)](https://travis-ci.org/boxen/puppet-openssl)

## Usage

```puppet
include openssl
```
