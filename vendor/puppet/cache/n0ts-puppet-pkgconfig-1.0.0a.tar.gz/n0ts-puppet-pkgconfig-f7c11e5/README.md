# Pkgconfig Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-pkgconfig.png?branch=master)](https://travis-ci.org/boxen/puppet-pkgconfig)

## Usage

```puppet
include pkgconfig
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`
