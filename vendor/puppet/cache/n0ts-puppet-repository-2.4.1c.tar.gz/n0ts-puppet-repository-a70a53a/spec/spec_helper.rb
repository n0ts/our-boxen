require 'rspec-puppet'

RSpec.configure do |c|
end
